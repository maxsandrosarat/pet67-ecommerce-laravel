<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <img src="/storage/logo/pet67_logo3600.png" alt="logo_pet67" width="8%">
    <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
        <ul class="navbar-nav mr-auto">
            <!--WEB-->
            <?php if(auth()->guard("web")->check()): ?>
            <li <?php if($current=="home"): ?> class="nav-item active" <?php else: ?> class="nav-item" <?php endif; ?>>
                <a class="nav-link" href="/home">Principal</a>
            </li>
            <li <?php if($current=="compras"): ?> class="nav-item active" <?php else: ?> class="nav-item" <?php endif; ?>>
                <a class="nav-link" href="<?php echo e(route('carrinho.compras')); ?>">Minhas Compras</a>
            </li>
            <li <?php if($current=="carrinho"): ?> class="nav-item active" <?php else: ?> class="nav-item" <?php endif; ?>>
                <a class="nav-link" href="<?php echo e(route('carrinho.index')); ?>">Carrinho</a>
            </li>
            <li <?php if($current=="enderecos"): ?> class="nav-item active" <?php else: ?> class="nav-item" <?php endif; ?>>
                <a class="nav-link" href="/enderecos">Meus Endereços</a>
            </li>
            <?php endif; ?>

            <!--DESLOGADO-->
            <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item">
                <a class="nav-link" href="/">Principal</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login (Cliente)')); ?></a>
            </li>

            <?php if(Route::has('register')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Cadastre-se')); ?></a>
            </li>
            <?php endif; ?>

            <li class="nav-item">
                <a class="nav-link" href="/admin">Login (Admin)</a>
            </li>

            <!--LOGADO-->
            <?php else: ?>
            <!--LOGOUT-->
            <li class="nav-item dropdown" class="nav-item">
                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?>

                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
            <?php endif; ?>
        </ul>
    </div>
  </nav><?php /**PATH C:\Users\maxsa\Desktop\GitHub\laravel-ecommerce-pet67\resources\views/components/componente_navbar_cliente.blade.php ENDPATH**/ ?>