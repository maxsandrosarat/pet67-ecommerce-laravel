<footer class="blockquote-footer" style="text-align: center;">
    <div class="copyright">
        &copy; Desenvolvido por Maxsandro Sarat. Todos os direitos reservados.
    </div>
</footer><?php /**PATH C:\Users\maxsa\Desktop\GitHub\laravel-ecommerce-pet67\resources\views/components/componente_footer.blade.php ENDPATH**/ ?>