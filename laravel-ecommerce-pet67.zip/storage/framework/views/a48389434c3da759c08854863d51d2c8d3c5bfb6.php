<div id="filtros" class="col">
    <div class="card-deck ">
        <div class="card border border-primary">
            <div class="card-body bg-light mb-3">
                <h5>Busca</h5>
                <form class="form-inline my-2 my-lg-0" method="GET" action="/busca">
                    <?php echo csrf_field(); ?>
                    <label for="categoria">Categoria:</label>
                    <select id="categoria" name="categoria">
                        <option value="">__Selecione__</option>
                        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <br/><br/>
                    <label for="tipo">Tipo do Animal:</label>
                    <select id="tipo" name="tipo">
                        <option value="">__Selecione__</option>
                        <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <br/><br/>
                    <label for="fase">Fase do Animal:</label>
                    <select id="fase" name="fase">
                        <option value="">__Selecione__</option>
                        <option value="filhote">Filhote</option>
                        <option value="adulto">Adulto</option>
                        <option value="castrado">Castrado</option>
                        <option value="todas">Todas</option>
                    </select>
                    <br/><br/>
                    <label for="marca">Marca do Produto:</label>
                    <select id="marca" name="marca">
                        <option value="">__Selecione__</option>
                        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <br/><br/>
                    <input class="form-control mr-sm-2" type="text" size="15" placeholder="Nome do Produto" name="nome" id="nome">
                    <br/><br/>
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\maxsa\Desktop\GitHub\laravel-ecommerce-pet67\resources\views/components/componente_filtro.blade.php ENDPATH**/ ?>