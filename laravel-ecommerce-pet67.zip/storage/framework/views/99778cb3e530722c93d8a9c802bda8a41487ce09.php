<?php $__env->startSection('body'); ?>
  <div class="row">
    <div id="filtros" class="col">
      <div class="card-deck ">
          <div class="card border border-primary">
              <div class="card-body bg-light mb-3">
                  <h5>Busca</h5>
                  <form class="form-inline my-2 my-lg-0" method="GET" action="/busca">
                      <?php echo csrf_field(); ?>
                      <label for="categoria">Categoria:</label>
                      <select id="categoria" name="categoria">
                          <option value="">__Selecione__</option>
                          <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->nome); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <br/><br/>
                      <label for="tipo">Tipo do Animal:</label>
                      <select id="tipo" name="tipo">
                          <option value="">__Selecione__</option>
                          <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nome); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <br/><br/>
                      <label for="fase">Fase do Animal:</label>
                      <select id="fase" name="fase">
                          <option value="">__Selecione__</option>
                          <option value="filhote">Filhote</option>
                          <option value="adulto">Adulto</option>
                          <option value="castrado">Castrado</option>
                          <option value="todas">Todas</option>
                      </select>
                      <br/><br/>
                      <label for="marca">Marca do Produto:</label>
                      <select id="marca" name="marca">
                          <option value="">__Selecione__</option>
                          <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->nome); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <br/><br/>
                      <input class="form-control mr-sm-2" type="text" size="15" placeholder="Nome do Produto" name="nome" id="nome">
                      <br/><br/>
                      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
                  </form>
              </div>
          </div>
      </div>
    </div>
    <div id="produtos" class="col-8">
      <?php if(count($prods)==0): ?>
            <br/>
            <?php if($tipo=="painel"): ?>
            <h5>Sem produtos cadastrados!</h5>
            <?php else: ?>
            <h5>Sem resultados para busca!</h5>
            <?php endif; ?>
      <?php else: ?>
        <?php if($pagina=="promocao"): ?><h2 class="promocao">Promoções</h2><?php endif; ?>
        <h5>Exibindo <?php echo e($prods->count()); ?> de <?php echo e($prods->total()); ?> de Produtos (<?php echo e($prods->firstItem()); ?> a <?php echo e($prods->lastItem()); ?>)</h5>
        <div class="card-columns">
          <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card text-white bg-info">
            <button type="button" data-toggle="modal" data-target="#exampleModalFoto<?php echo e($prod->id); ?>"><?php if($prod->foto!=""): ?><img class="card-img-top" style="margin:0px; padding:0px;" src="/storage/<?php echo e($prod->foto); ?>" alt="foto_produto"><?php endif; ?></button>
            <!-- Modal -->
            <div class="modal fade bd-example-modal-lg" id="exampleModalFoto<?php echo e($prod->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img src="/storage/<?php echo e($prod->foto); ?>" alt="foto_produto" style="width: 100%">
                </div>
                </div>
            </div>
            </div>
            <div class="card-body">
              <p class="card-text"><?php echo e($prod->nome); ?> <?php echo e($prod->tipo_animal->nome); ?> <?php if($prod->tipo_fase=='filhote'): ?> Filhote <?php else: ?> <?php if($prod->tipo_fase=='adulto'): ?> Adulto <?php else: ?> <?php if($prod->tipo_fase=='castrado'): ?> Castrado <?php endif; ?> <?php endif; ?> <?php endif; ?> <?php echo e($prod->marca->nome); ?> <?php if($prod->embalagem!="Unidade"): ?> <?php echo e($prod->embalagem); ?> <?php endif; ?> <br/> <h6><?php echo e('R$ '.number_format($prod->preco, 2, ',', '.')); ?></h6>
                <form method="POST" action="<?php echo e(route('carrinho.adicionar')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($prod->id); ?>">
                <button class="btn btn-success" data-toggle="tooltip" data-placement="top" title="O produto será adicionado ao seu carrinho">Comprar</button>
                <?php if($prod->promocao==1): ?><h6 class="promocao">Promoção</h6><?php endif; ?>
                </form>
              </p>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="card-footer">
          <?php echo e($prods->links()); ?>

        </div>
      <?php endif; ?>
      </div>
    <div id="anuncios" class="col">
        <p>Parceiros</p>
        <?php $__currentLoopData = $anuncios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anuncio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e($anuncio->link); ?>" target="_blank"><img class="card-img-top" style="margin:0px; padding:0px;" src="/storage/<?php echo e($anuncio->foto); ?>" alt="<?php echo e($anuncio->nome); ?>"></a>
          <br/><br/>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_principal', ["current"=>"home"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxsa\Desktop\GitHub\laravel-ecommerce-pet67\resources\views/welcome.blade.php ENDPATH**/ ?>