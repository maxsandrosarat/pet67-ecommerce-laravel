

<?php $__env->startSection('body'); ?>

<div class="container">
    <h3>Produtos no carrinho</h3>
    <div scope="row">
        <?php if(Session::has('mensagem-sucesso')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">x</button>
                <strong><?php echo e(Session::get('mensagem-sucesso')); ?></strong>
            </div>
        <?php endif; ?>
        <?php if(Session::has('mensagem-falha')): ?>
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert">x</button>
                <strong><?php echo e(Session::get('mensagem-falha')); ?></strong>
            </div>
        <?php endif; ?>
        <?php $__empty_1 = true; $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div>
                <h5 scope="col"> Pedido: <?php echo e($pedido->id); ?> </h5>
                <h5 scope="col"> Criado em: <?php echo e($pedido->created_at->format('d/m/Y H:i')); ?> </h5>
            </div>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th></th>
                        <th>Qtd</th>
                        <th>Produto</th>
                        <th>Valor Unit.</th>
                        <th>Desconto(s)</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $total_pedido = 0;
                    ?>
                    <?php $__currentLoopData = $pedido->pedido_produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido_produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td>
                            <img width="100" height="100" src="/storage/<?php echo e($pedido_produto->produto->foto); ?>">
                        </td>
                        <td class="center-align">
                            <div class="center-align">
                                <a class="col l4 m4 s4" href="#" onclick="carrinhoRemoverProduto(<?php echo e($pedido->id); ?>, <?php echo e($pedido_produto->produto_id); ?>, 1 )">
                                    <i class="material-icons small">remove_circle_outline</i>
                                </a>
                                <span class="col l4 m4 s4"> <?php echo e($pedido_produto->qtd); ?> </span>
                                <a class="col l4 m4 s4" href="#" onclick="carrinhoAdicionarProduto(<?php echo e($pedido_produto->produto_id); ?>)">
                                    <i class="material-icons small">add_circle_outline</i>
                                </a>
                            </div>
                            <a href="#" style="text-decoration:none;"onclick="carrinhoRemoverProduto(<?php echo e($pedido->id); ?>, <?php echo e($pedido_produto->produto_id); ?>, 0)" data-toggle="tooltip" data-placement="top" title="Remover produto do carrinho?">Remover Produto</a>
                        </td>
                        <td> <?php echo e($pedido_produto->produto->nome); ?> <?php echo e($pedido_produto->produto->tipo_animal->nome); ?> <?php if($pedido_produto->produto->tipo_fase=='filhote'): ?> Filhote <?php else: ?> <?php if($pedido_produto->produto->tipo_fase=='adulto'): ?> Adulto <?php else: ?> <?php if($pedido_produto->produto->tipo_fase=='castrado'): ?> Castrado <?php endif; ?> <?php endif; ?> <?php endif; ?> <?php echo e($pedido_produto->produto->marca->nome); ?> <?php if($pedido_produto->produto->embalagem!="Unidade"): ?> <?php echo e($pedido_produto->produto->embalagem); ?> <?php endif; ?></td>
                        <td>R$ <?php echo e(number_format($pedido_produto->produto->preco, 2, ',', '.')); ?></td>
                        <td>R$ <?php echo e(number_format($pedido_produto->descontos, 2, ',', '.')); ?></td>
                        <?php
                            $total_produto = $pedido_produto->valores - $pedido_produto->descontos;
                            $total_pedido += $total_produto;
                        ?>
                        <td>R$ <?php echo e(number_format($total_produto, 2, ',', '.')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div scope="row">
                <strong >Total do pedido: </strong>
                <span scope="col">R$ <?php echo e(number_format($total_pedido, 2, ',', '.')); ?></span>
            </div>
            <div scope="row">
                <form method="POST" action="<?php echo e(route('carrinho.desconto')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="pedido_id" value="<?php echo e($pedido->id); ?>">
                    <strong >Cupom de desconto: </strong>
                    <input  type="text" name="cupom">
                    <button type="submit" class="btn btn-primary">Validar</button>
                </form>
            </div>
            <br/>
            <div>
                <a type="button" class="btn btn-warning" data-toggle="tooltip" data-placement="top" title="Voltar a página inicial para continuar comprando?" href="<?php echo e(route('index')); ?>">Continuar comprando</a>
                <br/><br/>
                <form method="POST" action="<?php echo e(route('carrinho.concluir')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="pedido_id" value="<?php echo e($pedido->id); ?>">
                    <?php $__empty_2 = true; $__currentLoopData = $enderecos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endereco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                    <h6>Selecione endereço para entrega:</h6>
                    <input type="radio" id="endereco<?php echo e($endereco->id); ?>" name="endereco" value="<?php echo e($endereco->id); ?>" required>
                    <label for="endereco<?php echo e($endereco->id); ?>"><?php echo e($endereco->rua); ?>, <?php echo e($endereco->numero); ?> (<?php echo e($endereco->complemento); ?>) - <?php echo e($endereco->bairro); ?> - <?php echo e($endereco->cidade); ?> - <?php echo e($endereco->uf); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                    <h6>Nenhum endereço cadastrado</h6>
                    <a class="btn btn-primary" href="/enderecos">Cadastrar</a>
                    <br/>
                    <?php endif; ?>
                    <br/>
                    <button type="submit" class="btn btn-success" data-toggle="tooltip" data-placement="top" title="Adquirir os produtos concluindo a compra?">
                        Concluir compra
                    </button>   
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h5>Não há nenhum pedido no carrinho</h5>
            <a type="button" class="btn btn-warning" data-toggle="tooltip" data-placement="top" title="Voltar a página inicial para continuar comprando?" href="<?php echo e(route('index')); ?>">Continuar comprando</a>
        <?php endif; ?>
    </div>
</div>

<form id="form-remover-produto" method="POST" action="<?php echo e(route('carrinho.remover')); ?>">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('DELETE')); ?>

    <input type="hidden" name="pedido_id">
    <input type="hidden" name="produto_id">
    <input type="hidden" name="item">
</form>
<form id="form-adicionar-produto" method="POST" action="<?php echo e(route('carrinho.adicionar')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_cliente', ["current"=>"carrinho"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxsa\Desktop\GitHub\laravel-ecommerce-pet67\resources\views/cliente/carrinho.blade.php ENDPATH**/ ?>