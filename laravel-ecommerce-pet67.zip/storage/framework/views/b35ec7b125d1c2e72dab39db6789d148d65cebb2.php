<?php $__env->startSection('body'); ?>
<div class="jumbotron bg-light border border-secondary">
    <div class="row">
        <div class="card-deck">
            <div class="card border border-primary">
                <div class="card-body">
                    <h5>Estoque</h5>
                    <p class="card-text">
                        Veja suas entradas e saídas!
                    </p>
                    <a href="/relatorios/estoque" class="btn btn-primary">Verificar</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_admin', ["current"=>"relatorios"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxsa\Desktop\GitHub\laravel-ecommerce-pet67\resources\views/relatorios/home_relatorios.blade.php ENDPATH**/ ?>