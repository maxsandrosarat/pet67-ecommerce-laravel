<nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <img src="/storage/logo/pet67_logo3600.png" alt="logo_pet67" width="10%">
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
      <ul class="navbar-nav mr-auto">
          <li <?php if($current=="home"): ?> class="nav-item active" <?php else: ?> class="nav-item" <?php endif; ?>>
              <a class="nav-link" href="/">Principal</a>
          </li>
          <li <?php if($current=="produtos"): ?> class="nav-item active" <?php else: ?> class="nav-item" <?php endif; ?>>
              <a class="nav-link" href="/produtos">Todos os Produtos</a>
          </li>
          <li <?php if($current=="animais"): ?> class="nav-item active" <?php else: ?> class="nav-item" <?php endif; ?>>
            <a class="nav-link" href="/animais">Animais</a>
          </li>
          <li <?php if($current=="servicos"): ?> class="nav-item dropdown active" <?php else: ?> class="nav-item dropdown" <?php endif; ?>>
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Serviços
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" href="#">Banho & Tosa</a>
                <a class="dropdown-item" href="#">Veterinária</a>
              </div>
            </li>
      </ul>
  </div>
</nav><?php /**PATH C:\Users\maxsa\Desktop\GitHub\laravel-ecommerce-pet67\resources\views/components/componente_navbar_web.blade.php ENDPATH**/ ?>