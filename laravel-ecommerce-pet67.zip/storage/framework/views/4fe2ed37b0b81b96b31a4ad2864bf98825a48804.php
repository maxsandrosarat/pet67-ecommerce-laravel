

<?php $__env->startSection('body'); ?>
    <div class="card border">
        <div class="card-body">
            <h5 class="card-title">Controle de Estoque</h5>
            <?php if(count($prods)==0): ?>
                <br/><br/>
                <div class="alert alert-danger" role="alert">
                    Sem produtos cadastrados!
                </div>
            <?php else: ?>
            <div class="card border">
                <h5>Filtros: </h5>
                <form class="form-inline my-2 my-lg-0" method="GET" action="/admin/estoque/filtro">
                    <?php echo csrf_field(); ?>
                    <input class="form-control mr-sm-2" type="text" placeholder="Nome do Produto" name="nome">
                    <select id="categoria" name="categoria">
                        <option value="">Selecione uma categoria</option>
                        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <select id="tipo" name="tipo">
                        <option value="">Selecione um tipo</option>
                        <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <select id="fase" name="fase">
                        <option value="">Selecione uma fase</option>
                        <option value="filhote">Filhote</option>
                        <option value="adulto">Adulto</option>
                        <option value="castrado">Castrado</option>
                        <option value="todas">Todas</option>
                    </select>
                    <select id="marca" name="marca">
                        <option value="">Selecione uma marca</option>
                        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Filtrar</button>
                </form>
                </div>
                <br/>
            <h5>Exibindo <?php echo e($prods->count()); ?> de <?php echo e($prods->total()); ?> de Produtos (<?php echo e($prods->firstItem()); ?> a <?php echo e($prods->lastItem()); ?>)</h5>
            <table class="table table-striped table-ordered table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>Foto</th>
                        <th>Nome</th>
                        <th>Tipo Animal</th>
                        <th>Tipo Fase</th>
                        <th>Marca</th>
                        <th>Embalagem</th>
                        <th>Estoque</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td width="120"><button type="button" data-toggle="modal" data-target="#exampleModalFoto<?php echo e($prod->id); ?>"><?php if($prod->foto!=""): ?><img style="margin:0px; padding:0px;" src="/storage/<?php echo e($prod->foto); ?>" alt="foto_produto" width="50%"><?php endif; ?></button></td>
                        <!-- Modal -->
                        <div class="modal fade bd-example-modal-lg" id="exampleModalFoto<?php echo e($prod->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <img src="/storage/<?php echo e($prod->foto); ?>" alt="foto_produto">
                            </div>
                            </div>
                        </div>
                        </div>
                        <td><?php echo e($prod->nome); ?></td>
                        <td><?php echo e($prod->tipo_animal->nome); ?></td>
                        <td><?php if($prod->tipo_fase=='filhote'): ?> Filhote <?php else: ?> <?php if($prod->tipo_fase=='adulto'): ?> Adulto <?php else: ?> <?php if($prod->tipo_fase=='castrado'): ?> Castrado <?php else: ?> Todas <?php endif; ?> <?php endif; ?> <?php endif; ?></td>
                        <td><?php echo e($prod->marca->nome); ?></td>
                        <td><?php echo e($prod->embalagem); ?></td>
                        <td><?php echo e($prod->estoque); ?></td>
                        <td>
                            <button type="button" class="btn btn-sm btn-info" data-toggle="modal" data-target="#exampleModalEntrada<?php echo e($prod->id); ?>">
                                Entrada
                            </button>
                            <!-- Modal -->
                            <div class="modal fade" id="exampleModalEntrada<?php echo e($prod->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Entrada de Produtos</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="card border">
                                            <div class="card-body">
                                                <form action="/admin/estoque/entrada/<?php echo e($prod->id); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="form-group">
                                                        <h6>Produto Selecionado:</h6>
                                                        <h5><?php echo e($prod->nome); ?> <?php echo e($prod->tipo_animal->nome); ?> <?php if($prod->tipo_fase=='filhote'): ?> Filhote <?php else: ?> <?php if($prod->tipo_fase=='adulto'): ?> Adulto <?php else: ?> <?php if($prod->tipo_fase=='castrado'): ?> Castrado <?php endif; ?> <?php endif; ?> <?php endif; ?> <?php echo e($prod->marca->nome); ?> <?php if($prod->embalagem!="Unidade"): ?> <?php echo e($prod->embalagem); ?> <?php endif; ?></h5>
                                                        <h6>Quantidade atual:</h6>
                                                        <h5><?php echo e($prod->estoque); ?></h5>
                                                        <input type="hidden" name="produto" value="<?php echo e($prod->id); ?>">
                                                        <label for="qtd">Quantidade de Entrada</label>
                                                        <input type="number" id="qtd" name="qtd" required>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-primary btn-sn">Salvar</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#exampleModalSaida<?php echo e($prod->id); ?>">
                                Saída
                            </button>
                            <!-- Modal -->
                            <div class="modal fade" id="exampleModalSaida<?php echo e($prod->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Saída de Produtos</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="card border">
                                            <div class="card-body">
                                                <form action="/admin/estoque/saida/<?php echo e($prod->id); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="form-group">
                                                        <h6>Produto Selecionado:</h6>
                                                        <h5><?php echo e($prod->nome); ?> <?php echo e($prod->tipo_animal->nome); ?> <?php if($prod->tipo_fase=='filhote'): ?> Filhote <?php else: ?> <?php if($prod->tipo_fase=='adulto'): ?> Adulto <?php else: ?> <?php if($prod->tipo_fase=='castrado'): ?> Castrado <?php endif; ?> <?php endif; ?> <?php endif; ?> <?php echo e($prod->marca->nome); ?> <?php if($prod->embalagem!="Unidade"): ?> <?php echo e($prod->embalagem); ?> <?php endif; ?></h5>
                                                        <h6>Quantidade atual:</h6>
                                                        <h5><?php echo e($prod->estoque); ?></h5>
                                                        <input type="hidden" name="produto" value="<?php echo e($prod->id); ?>">
                                                        <label for="qtd">Quantidade de Saída</label>
                                                        <input type="number" id="qtd" name="qtd" required>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-primary btn-sn">Salvar</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <div class="card-footer">
            <?php echo e($prods->links()); ?>

        </div>
    </div>
    <br>
    <a href="/cadastros" class="btn btn-success">Voltar</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin', ["current"=>"estoque"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxsa\Desktop\GitHub\laravel-ecommerce-pet67\resources\views/estoque/estoque_produtos.blade.php ENDPATH**/ ?>