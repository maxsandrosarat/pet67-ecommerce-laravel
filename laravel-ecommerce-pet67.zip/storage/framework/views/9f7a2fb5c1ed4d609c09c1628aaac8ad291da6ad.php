

<?php $__env->startSection('body'); ?>

<div class="container">
    <div scope="row">
        <?php if(Session::has('mensagem-sucesso')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">x</button>
                <strong><?php echo e(Session::get('mensagem-sucesso')); ?></strong>
            </div>
        <?php endif; ?>
        <?php if(Session::has('mensagem-falha')): ?>
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert">x</button>
                <strong><?php echo e(Session::get('mensagem-falha')); ?></strong>
            </div>
        <?php endif; ?>
        <hr/>
        <div>
            <h4 style="color: green;">Compras Efetuadas</h4>
            <hr/>
            <?php $__empty_1 = true; $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Pedido</th>
                            <th>Cliente</th>
                            <th>Criação</th>
                            <th>Produtos</th>
                            <th>Cancelados</th>
                            <th>Valor</th>
                            <th>Desconto</th>
                            <th>Total</th>
                            <th>Ações</th>
                         </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($pedido->id); ?></td>
                            <td><?php echo e($pedido->user->name); ?></td>
                            <td><?php echo e($pedido->created_at->format('d/m/Y H:i')); ?></td>
                        <?php
                            $total_produto = 0;
                            $total_valor = 0;
                            $total_desconto = 0;
                            $total_pedido = 0;
                            $itens_cancelados = 0;
                        ?>
                        <td>
                            <ul>
                        <?php $__currentLoopData = $pedido->pedido_produtos_itens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido_produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            if($pedido_produto->status == 'FEITO'){
                                $total_produto += $pedido_produto->valor - $pedido_produto->desconto;
                                $total_valor += $pedido_produto->valor;
                                $total_desconto += $pedido_produto->desconto;
                                $total_pedido += $total_produto;
                            } elseif($pedido_produto->status == 'CANCEL'){
                                $itens_cancelados++;
                            }
                            ?>
                            <?php if($pedido_produto->status == 'FEITO'): ?>
                                <li><?php echo e($pedido_produto->produto->nome); ?> <?php echo e($pedido_produto->produto->tipo_animal->nome); ?> <?php if($pedido_produto->produto->tipo_fase=='filhote'): ?> Filhote <?php else: ?> <?php if($pedido_produto->produto->tipo_fase=='adulto'): ?> Adulto <?php else: ?> <?php if($pedido_produto->produto->tipo_fase=='castrado'): ?> Castrado <?php endif; ?> <?php endif; ?> <?php endif; ?> <?php echo e($pedido_produto->produto->marca->nome); ?> <?php if($pedido_produto->produto->embalagem!="Unidade"): ?> <?php echo e($pedido_produto->produto->embalagem); ?> <?php endif; ?></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                                <td><?php if($itens_cancelados>0): ?> SIM <?php else: ?> NÃO <?php endif; ?></td>
                                <td>R$ <?php echo e(number_format($total_valor, 2, ',', '.')); ?></td>
                                <td>R$ <?php echo e(number_format($total_desconto, 2, ',', '.')); ?></td>
                                <td>R$ <?php echo e(number_format($total_produto, 2, ',', '.')); ?></td>
                                <td>
                                    <a href="/admin/pedidos/pagar/<?php echo e($pedido->id); ?>" type="button" class="btn btn-success">PAGAR</a>
                                    <a href="/admin/pedidos/cancelar/<?php echo e($pedido->id); ?>" type="button" class="btn btn-danger">CANCELAR</a>
                                </td>
                            </tr>
                        </tbody>
                </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h5>Ninguém fez pedidos ainda.</h5>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-footer">
        <?php echo e($pedidos->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_admin', ["current"=>"pedidos"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxsa\Desktop\GitHub\laravel-ecommerce-pet67\resources\views/admin/pedidos_feitos.blade.php ENDPATH**/ ?>