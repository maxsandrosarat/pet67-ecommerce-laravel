<?php $__env->startSection('body'); ?>
  <?php if(count($animais)==0): ?>
  <br/>
  <h5>Sem animais cadastrados!</h5>
  <?php else: ?>
  <div class="row row-cols-1 row-cols-md-2">
    <?php $__currentLoopData = $animais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col mb-4">
      <div class="card">
        <img src="/storage/<?php echo e($animal->foto); ?>" class="card-img-top" alt="<?php echo e($animal->nome); ?>">
        <div class="card-body">
          <h3 class="card-title"><?php echo e($animal->nome); ?></h3>
          <p class="card-text"><?php echo e($animal->descricao); ?></p>
          <p class="card-text"> <small class="text-muted"><?php echo e('R$ '.number_format($animal->preco, 2, ',', '.')); ?></small> </p>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_principal', ["current"=>"animais"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxsa\Desktop\GitHub\laravel-ecommerce-pet67\resources\views/animais.blade.php ENDPATH**/ ?>