

<?php $__env->startSection('body'); ?>

<div class="container">
    <div scope="row">
        <?php if(Session::has('mensagem-sucesso')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">x</button>
                <strong><?php echo e(Session::get('mensagem-sucesso')); ?></strong>
            </div>
        <?php endif; ?>
        <?php if(Session::has('mensagem-falha')): ?>
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert">x</button>
                <strong><?php echo e(Session::get('mensagem-falha')); ?></strong>
            </div>
        <?php endif; ?>
        <hr/>
        <div>
            <h4 style="color: green;">Compras Concluídas</h4>
            <?php $__empty_1 = true; $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <hr/>
                <div>
                    <h5 scope="col"> Pedido: <?php echo e($pedido->id); ?> </h5>
                    <h5 scope="col"> Criado em: <?php echo e($pedido->created_at->format('d/m/Y H:i')); ?> </h5>
                </div>
                <form method="POST" action="<?php echo e(route('carrinho.cancelar')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="pedido_id" value="<?php echo e($pedido->id); ?>">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th colspan="2"></th>
                                <th>Produto</th>
                                <th>Valor</th>
                                <th>Desconto</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            $total_pedido = 0;
                        ?>
                        <?php $__currentLoopData = $pedido->pedido_produtos_itens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido_produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $total_produto = $pedido_produto->valor - $pedido_produto->desconto;
                                if($pedido_produto->status == 'FEITO'){
                                    $total_pedido += $total_produto;
                                }''
                            ?>
                            <tr>
                                <td>
                                    <?php if($pedido_produto->status == 'FEITO'): ?>
                                        <p>
                                            <input type="checkbox" id="item-<?php echo e($pedido_produto->id); ?>" name="id[]" value="<?php echo e($pedido_produto->id); ?>" />
                                            <label for="item-<?php echo e($pedido_produto->id); ?>">Cancelar    </label>
                                        </p>
                                    <?php else: ?>
                                        <?php if($pedido_produto->status == 'PAGO'): ?>
                                        <strong style="color: green;" class="red-text">PAGO</strong>
                                        <?php else: ?>
                                        <strong style="color: red;" class="red-text">CANCELADO</strong>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <img width="100" height="100" src="/storage/<?php echo e($pedido_produto->produto->foto); ?>">
                                </td>
                                <td><?php echo e($pedido_produto->produto->nome); ?> <?php echo e($pedido_produto->produto->tipo_animal->nome); ?> <?php if($pedido_produto->produto->tipo_fase=='filhote'): ?> Filhote <?php else: ?> <?php if($pedido_produto->produto->tipo_fase=='adulto'): ?> Adulto <?php else: ?> <?php if($pedido_produto->produto->tipo_fase=='castrado'): ?> Castrado <?php endif; ?> <?php endif; ?> <?php endif; ?> <?php echo e($pedido_produto->produto->marca->nome); ?> <?php if($pedido_produto->produto->embalagem!="Unidade"): ?> <?php echo e($pedido_produto->produto->embalagem); ?> <?php endif; ?></td>
                                <td>R$ <?php echo e(number_format($pedido_produto->valor, 2, ',', '.')); ?></td>
                                <td>R$ <?php echo e(number_format($pedido_produto->desconto, 2, ',', '.')); ?></td>
                                <td>R$ <?php echo e(number_format($total_produto, 2, ',', '.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="3"></td>
                                <td><strong>Total do pedido</strong></td>
                                <td>R$ <?php echo e(number_format($total_pedido, 2, ',', '.')); ?></td>
                            </tr>
                            <tr>
                                <td colspan="2">Endereço de Entrega:</td>
                                <?php $__currentLoopData = $enderecos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endereco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($endereco->id == $pedido->endereco_id): ?>
                                    <td colspan="4"><b><?php echo e($endereco->rua); ?>, <?php echo e($endereco->numero); ?> (<?php echo e($endereco->complemento); ?>) - <?php echo e($endereco->bairro); ?> - <?php echo e($endereco->cidade); ?> - <?php echo e($endereco->uf); ?></b></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <button type="submit" class="btn btn-danger" data-position="bottom" data-delay="50" data-tooltip="Cancelar itens selecionados">
                                        Cancelar
                                    </button>   
                                </td>
                                <td colspan="3"></td>
                            </tr>
                        </tfoot>
                    </table>
                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h5 class="center">
                    <?php if($cancelados->count() > 0): ?>
                        Neste momento não há nenhuma compra valida.
                    <?php else: ?>
                        Você ainda não fez nenhuma compra.
                    <?php endif; ?>
                </h5>
            <?php endif; ?>
        </div>
        <hr/>
        <div>
            <h4 style="color: red;">Compras Canceladas</h4>
            <?php $__empty_1 = true; $__currentLoopData = $cancelados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <hr/>
                <h5 scope="col"> Pedido: <?php echo e($pedido->id); ?> </h5>
                <h5 scope="col"> Criado em: <?php echo e($pedido->created_at->format('d/m/Y H:i')); ?> </h5>
                <h5 scope="col"> Cancelado em: <?php echo e($pedido->updated_at->format('d/m/Y H:i')); ?> </h5>
                <table>
                    <thead>
                        <tr>
                            <th></th>
                            <th>Produto</th>
                            <th>Valor</th>
                            <th>Desconto</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $total_pedido = 0;
                        ?>
                        <?php $__currentLoopData = $pedido->pedido_produtos_itens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido_produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $total_produto = $pedido_produto->valor - $pedido_produto->desconto;
                                $total_pedido += $total_produto;
                            ?>
                        <tr>
                            <td>
                                <img width="100" height="100" src="/storage/<?php echo e($pedido_produto->produto->foto); ?>">
                            </td>
                            <td><?php echo e($pedido_produto->produto->nome); ?></td>
                            <td>R$ <?php echo e(number_format($pedido_produto->valor, 2, ',', '.')); ?></td>
                            <td>R$ <?php echo e(number_format($pedido_produto->desconto, 2, ',', '.')); ?></td>
                            
                            <td>R$ <?php echo e(number_format($total_produto, 2, ',', '.')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3"></td>
                            <td><strong>Total do pedido</strong></td>
                            <td>R$ <?php echo e(number_format($total_pedido, 2, ',', '.')); ?></td>
                        </tr>
                    </tfoot>
                </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h5 class="center">Nenhuma compra ainda foi cancelada.</h5>
            <?php endif; ?>
        </div>
        <hr/>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_cliente', ["current"=>"compras"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxsa\Desktop\GitHub\laravel-ecommerce-pet67\resources\views/cliente/compras.blade.php ENDPATH**/ ?>