<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <title>Pet67</title>
        <link rel="shortcut icon" href="/storage/logo/favicon.png"/>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        
        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    </head>
    <body>
        <div>
            <?php if(Route::has('login')): ?>
                    <div class="icons">
                        <a href="#" class="icon fa-phone" data-toggle="modal" data-target="#exampleModal" data-toggle="tooltip" data-placement="bottom" title="Contatos"><span class="label">Telefone</span></a>
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Telefone e WhatsApp</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <h5 class="icon fa-phone"/> (67) 3385-4316 <a href="tel:6733854316" type="button" class="btn btn-primary">Ligar</a>
                                <h5 class="icon fa-whatsapp"/> (67) 99143-0321 <a href="https://api.whatsapp.com/send?phone=5567991430321&text=Digite%20sua%20mensagem" type="button" class="btn btn-success">Mandar Mensagem</a>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                              </div>
                            </div>
                          </div>
                        </div>
                        <a href="https://www.facebook.com/Pet067/" target="_blank" class="icon fa-facebook" data-toggle="tooltip" data-placement="bottom" title="Facebook"><span class="label">Facebook</span></a>
                        <a href="https://www.instagram.com/pet67_/" target="_blank" class="icon fa-instagram" data-toggle="tooltip" data-placement="bottom" title="Instagram"><span class="label">Instagram</span></a>
                                                <!-- Button trigger modal -->
                        <a href="#" class="icon fa-envelope-o" data-toggle="modal" data-target="#exampleModa2" data-toggle="tooltip" data-placement="bottom" title="E-mail"><span class="label">Email</span></a>
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModa2" tabindex="-1" role="dialog" aria-labelledby="exampleModa2Label" aria-hidden="true">
                          <div class="modal-dialog" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModa2Label">Email para Elogios, Sugestões e Reclamações</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                sac.pet67@gmail.com <a href="mailto:pet67guaicurus@hotmail.com" type="button" class="btn btn-danger">Mandar um e-mail</a>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                              </div>
                            </div>
                          </div>
                        </div>
                        <!-- Button trigger modal -->
                        <a href="#" class="icon fa-map-marker" data-toggle="modal" data-target="#exampleModa3" data-toggle="tooltip" data-placement="bottom" title="Localização"><span class="label">Localização</span></a>
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModa3" tabindex="-1" role="dialog" aria-labelledby="exampleModa2Label" aria-hidden="true">
                          <div class="modal-dialog" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModa2Label">Endereço</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <a href="https://goo.gl/maps/w4xaUQwcgm9pUbAo8"><iframe style="width: 100%" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3736.249946422303!2d-54.644058085619484!3d-20.53695176277126!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9486e595b0f60b43%3A0x2e91bed800abbd94!2sPet67!5e0!3m2!1spt-BR!2sbr!4v1589060520779!5m2!1spt-BR!2sbr" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe></a>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>
                    <?php if(auth()->guard()->check()): ?>
                        <div class="links">
                        <a href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                            SAIR
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                        </div>
                      
                        <div class="links">
                          <a href="<?php echo e(route('carrinho.index')); ?>">Carrinho</a>
                        </div>

                        <div class="links">
                          <a href="<?php echo e(route('carrinho.compras')); ?>">Minhas compras</a>
                        </div>

                        <div class="links">
                          <a href="#">Olá, <?php echo e(Auth::user()->name); ?></a>
                        </div>
                    <?php else: ?>
                        <!-- Button trigger modal -->
                        <div class="links">
                          <a href="#" data-toggle="modal" data-target=".bd-example-modal-lgLog">Login</a>
                        </div>
                        
                        <!-- Modal -->
                        <div class="modal fade bd-example-modal-lgLog" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Login <a class="btn btn-link" href="/admin">Login como Admin</a></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="card-body">
                                  <form method="POST" action="<?php echo e(route('login')); ?>">
                                      <?php echo csrf_field(); ?>
              
                                      <div class="form-group row">
                                          <label for="email" class="col-md-4 col-form-label text-md-right">E-mail</label>
              
                                          <div class="col-md-6">
                                              <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
              
                                              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                  <span class="invalid-feedback" role="alert">
                                                      <strong><?php echo e($message); ?></strong>
                                                  </span>
                                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>
                                      </div>
              
                                      <div class="form-group row">
                                          <label for="password" class="col-md-4 col-form-label text-md-right">Senha</label>
              
                                          <div class="col-md-6">
                                              <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
              
                                              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                  <span class="invalid-feedback" role="alert">
                                                      <strong><?php echo e($message); ?></strong>
                                                  </span>
                                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>
                                      </div>
              
                                      <div class="form-group row">
                                          <div class="col-md-6 offset-md-4">
                                              <div class="form-check">
                                                  <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
              
                                                  <label class="form-check-label" for="remember">
                                                      Lembrar Login
                                                  </label>
                                              </div>
                                          </div>
                                      </div>
              
                                      <div class="form-group row mb-0">
                                          <div class="col-md-8 offset-md-4">
                                              <button type="submit" class="btn btn-primary">
                                                  <?php echo e(__('Login')); ?>

                                              </button>
              
                                              <?php if(Route::has('password.request')): ?>
                                                  <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                                      Esqueceu sua senha?
                                                  </a>
                                              <?php endif; ?>
                                          </div>
                                      </div>
                                  </form>
                              </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <!-- Button trigger modal -->
                        <div class="links">
                            <a href="#" data-toggle="modal" data-target=".bd-example-modal-lgCad">Cadastre-se</a>
                        </div>
                        <!-- Modal -->
                        <div class="modal fade bd-example-modal-lgCad" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Cadastre-se</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="card-body">
                                    <form method="POST" action="<?php echo e(route('register')); ?>">
                                        <?php echo csrf_field(); ?>
                
                                        <div class="form-group row">
                                            <label for="name" class="col-md-4 col-form-label text-md-right">Nome</label>
                
                                            <div class="col-md-6">
                                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                
                                        <div class="form-group row">
                                            <label for="email" class="col-md-4 col-form-label text-md-right">E-mail</label>
                
                                            <div class="col-md-6">
                                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                
                                        <div class="form-group row">
                                            <label for="password" class="col-md-4 col-form-label text-md-right">Senha</label>
                
                                            <div class="col-md-6">
                                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">
                
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                
                                        <div class="form-group row">
                                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">Confirmação da Senha</label>
                
                                            <div class="col-md-6">
                                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                            </div>
                                        </div>  
                                </div>
                              </div>
                              <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Cadastrar</button>
                              </div>
                            </form>
                            </div>
                          </div>
                        </div>
                    <?php endif; ?>
            <?php endif; ?>
            <div class="container">
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                    </button>
                    <img src="/storage/logo/pet67_logo3600.png" alt="logo_pet67" width="10%">
                    <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="/">Principal</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="#">Promoções</a>
                          </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Produtos</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  Serviços
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                  <a class="dropdown-item" href="#">Banho & Tosa</a>
                                  <a class="dropdown-item" href="#">Veterinária</a>
                                  <a class="dropdown-item" href="#">Outros</a>
                                </div>
                              </li>
                              <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  Animais
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                  <a class="dropdown-item" href="#">Codornas</a>
                                  <a class="dropdown-item" href="#">Aves</a>
                                  <a class="dropdown-item" href="#">Outros</a>
                                </div>
                              </li>
                        </ul>
                    </div>
                  </nav>
                  <div class="row">
                      <div id="filtros" class="col">
                        <div class="card-deck ">
                            <div class="card border border-primary">
                                <div class="card-body bg-light mb-3">
                                    <h5>Busca</h5>
                                    <form class="form-inline my-2 my-lg-0" method="GET" action="/busca">
                                        <?php echo csrf_field(); ?>
                                        <label for="categoria">Categoria:</label>
                                        <select id="categoria" name="categoria">
                                            <option value="">__Selecione__</option>
                                            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->nome); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <br/><br/>
                                        <label for="tipo">Tipo do Animal:</label>
                                        <select id="tipo" name="tipo">
                                            <option value="">__Selecione__</option>
                                            <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nome); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <br/><br/>
                                        <label for="fase">Fase do Animal:</label>
                                        <select id="fase" name="fase">
                                            <option value="">__Selecione__</option>
                                            <option value="filhote">Filhote</option>
                                            <option value="adulto">Adulto</option>
                                            <option value="castrado">Castrado</option>
                                            <option value="todas">Todas</option>
                                        </select>
                                        <br/><br/>
                                        <label for="marca">Marca do Produto:</label>
                                        <select id="marca" name="marca">
                                            <option value="">__Selecione__</option>
                                            <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->nome); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <br/><br/>
                                        <input class="form-control mr-sm-2" type="text" size="15" placeholder="Nome do Produto" name="nome" id="nome">
                                        <br/><br/>
                                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                      </div>
                      <div id="produtos" class="col-8">
                        <?php if(count($prods)==0): ?>
                              <br/>
                              <?php if($tipo=="painel"): ?>
                              <h5>Sem produtos cadastrados!</h5>
                              <?php else: ?>
                              <h5>Sem resultados para busca!</h5>
                              <?php endif; ?>
                        <?php else: ?>
                          <h5>Exibindo <?php echo e($prods->count()); ?> de <?php echo e($prods->total()); ?> de Produtos (<?php echo e($prods->firstItem()); ?> a <?php echo e($prods->lastItem()); ?>)</h5>
                          <div class="card-columns">
                            <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card text-white bg-info">
                              <button type="button" data-toggle="modal" data-target="#exampleModalFoto<?php echo e($prod->id); ?>"><?php if($prod->foto!=""): ?><img class="card-img-top" style="margin:0px; padding:0px;" src="/storage/<?php echo e($prod->foto); ?>" alt="foto_produto"><?php endif; ?></button>
                              <!-- Modal -->
                              <div class="modal fade bd-example-modal-lg" id="exampleModalFoto<?php echo e($prod->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                              <div class="modal-dialog modal-lg" role="document">
                                  <div class="modal-content">
                                  <div class="modal-header">
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                      </button>
                                  </div>
                                  <div class="modal-body">
                                      <img src="/storage/<?php echo e($prod->foto); ?>" alt="foto_perfil" style="width: 100%">
                                  </div>
                                  </div>
                              </div>
                              </div>
                              <div class="card-body">
                                <p class="card-text"><?php echo e($prod->nome); ?> <?php echo e($prod->tipo_animal->nome); ?> <?php if($prod->tipo_fase=='filhote'): ?> Filhote <?php else: ?> <?php if($prod->tipo_fase=='adulto'): ?> Adulto <?php else: ?> <?php if($prod->tipo_fase=='castrado'): ?> Castrado <?php endif; ?> <?php endif; ?> <?php endif; ?> <?php echo e($prod->marca->nome); ?> <?php if($prod->embalagem!="Unidade"): ?> <?php echo e($prod->embalagem); ?> <?php endif; ?> <br/> <h6><?php echo e('R$ '.number_format($prod->preco, 2, ',', '.')); ?></h6>
                                  <form method="POST" action="<?php echo e(route('carrinho.adicionar')); ?>">
                                  <?php echo csrf_field(); ?>
                                  <input type="hidden" name="id" value="<?php echo e($prod->id); ?>">
                                  <button class="btn btn-success" data-toggle="tooltip" data-placement="top" title="O produto será adicionado ao seu carrinho">Comprar</button>   
                                  </form>
                                </p>
                              </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                          <div class="card-footer">
                            <?php echo e($prods->links()); ?>

                          </div>
                        <?php endif; ?>
                        </div>
                      <div id="anuncios" class="col">
                          <p>Parceiros</p>
                          <?php $__currentLoopData = $anuncios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anuncio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($anuncio->link); ?>" target="_blank"><img class="card-img-top" style="margin:0px; padding:0px;" src="/storage/<?php echo e($anuncio->foto); ?>" alt="<?php echo e($anuncio->nome); ?>"></a>
                            <br/><br/>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                  </div>
                  <footer class="blockquote-footer" style="text-align: center;">
                    <div class="copyright">
                        &copy; Desenvolvido por Maxsandro Sarat. Todos os direitos reservados.
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    </body>
</html>
<?php /**PATH C:\Users\maxsa\Desktop\GitHub\pet67\resources\views/welcome.blade.php ENDPATH**/ ?>