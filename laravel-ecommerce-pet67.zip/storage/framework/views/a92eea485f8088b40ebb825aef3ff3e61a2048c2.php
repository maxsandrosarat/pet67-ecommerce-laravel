<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="/storage/logo/favicon.png"/>
    
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <title>Pet67</title>

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <style>
        body{
            padding: 20px;
        }
        .container{
            margin-top: 20px;
        }
        td{
            text-align: justify;
        }
        #navLogin {
            color:red;
        }                        
    }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <?php $__env->startComponent('components.componente_navbar_admin', ["current"=>$current ?? '']); ?>
            <?php if (isset($__componentOriginal1ea3ce35c648689eeb10cece8fd2a89201f3aaca)): ?>
<?php $component = $__componentOriginal1ea3ce35c648689eeb10cece8fd2a89201f3aaca; ?>
<?php unset($__componentOriginal1ea3ce35c648689eeb10cece8fd2a89201f3aaca); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        </header>
        <?php if(auth()->guard()->check()): ?>
            <main>
                <?php if (! empty(trim($__env->yieldContent('body')))): ?>
                    <?php echo $__env->yieldContent('body'); ?>   
                <?php endif; ?>
            </main>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
            <main class="py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        <?php endif; ?>
        <?php $__env->startComponent('components.componente_footer'); ?>
        <?php if (isset($__componentOriginal745b014d21f64034a634a5d3026c7512b5110dc0)): ?>
<?php $component = $__componentOriginal745b014d21f64034a634a5d3026c7512b5110dc0; ?>
<?php unset($__componentOriginal745b014d21f64034a634a5d3026c7512b5110dc0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    </div>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>

<?php /**PATH C:\Users\maxsa\Desktop\GitHub\laravel-ecommerce-pet67\resources\views/layouts/app_admin.blade.php ENDPATH**/ ?>