

<?php $__env->startSection('body'); ?>
    <div class="card border">
        <div class="card-body">
            <h5 class="card-title">Lista de Produtos</h5>
            <a type="button" class="float-button" data-toggle="modal" data-target="#exampleModal" data-toggle="tooltip" data-placement="bottom" title="Adicionar Novo Produto">
                <i class="material-icons blue md-60">add_circle</i>
            </a>
            <br/><br/>
            <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Cadastro de Produto</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                    <div class="modal-body">
                        <div class="card border">
                            <div class="card-body">
                                <form action="/admin/produtos" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="foto">Foto</label>
                                        <input type="file" id="foto" name="foto" accept=".jpg,.png,jpeg">
                                        <br/>
                                        <b style="font-size: 80%;">Aceito apenas Imagens JPG e PNG (".jpg" e ".png")</b>
                                        <br/><br/>
                                        <label for="nome">Nome do Produto</label>
                                        <input type="text" class="form-control" name="nome" id="nome" placeholder="Exemplo: Ração" required>
                                        <br/>
                                        <label for="tipo">Tipo de Animal</label>
                                        <select id="tipo" name="tipo" required>
                                            <option value="">Selecione o tipo do animal</option>
                                            <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nome); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <br/><br/>
                                        <label for="fase">Fase do Animal:</label>
                                        <select id="fase" name="fase" required>
                                            <option value="">Selecione a fase do animal</option>
                                            <option value="filhote">Filhote</option>
                                            <option value="adulto">Adulto</option>
                                            <option value="castrado">Castrado</option>
                                            <option value="todas">Todas</option>
                                        </select>
                                        <br/><br/>
                                        <label for="marca">Marca</label>
                                        <select id="marca" name="marca" required>
                                            <option value="">Selecione a marca do produto</option>
                                            <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->nome); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <br/>
                                        <label for="embalagem">Embalagem do Produto</label>
                                        <input type="text" class="form-control" name="embalagem" id="embalagem" placeholder="Exemplo: 10 KG" required>
                                        <br/>
                                        <label for="preco">Preço do Produto</label>
                                        <input type="text" class="form-control" name="preco" id="preco" placeholder="Exemplo: 10.5" required>
                                        <br/>
                                        <label for="estoque">Estoque do Produto</label>
                                        <input type="number" class="form-control" name="estoque" id="estoque" placeholder="Exemplo: 100" required>
                                        <br/>
                                        <label for="categoria">Categoria</label>
                                        <select id="categoria" name="categoria" required>
                                            <option value="">Selecione</option>
                                            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->nome); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <h5>Ativo?</h5>
                                        <input type="radio" id="sim" name="ativo" value="sim" required>
                                        <label for="sim">Sim</label>
                                        <input type="radio" id="nao" name="ativo" value="nao" required>
                                        <label for="nao">Não</label>
                                        <h5>Promoção?</h5>
                                        <input type="radio" id="sim" name="promocao" value="1" required>
                                        <label for="sim">Sim</label>
                                        <input type="radio" id="nao" name="promocao" value="0" required>
                                        <label for="nao">Não</label>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary btn-sn">Salvar</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
            <?php if(count($prods)==0): ?>
                <br/><br/>
                <div class="alert alert-danger" role="alert">
                    Sem produtos cadastrados!
                </div>
            <?php else: ?>
            <div class="card border">
                <h5>Filtros: </h5>
                <form class="form-inline my-2 my-lg-0" method="GET" action="/admin/produtos/filtro">
                    <?php echo csrf_field(); ?>
                    <input class="form-control mr-sm-2" type="text" placeholder="Nome do Produto" name="nome">
                    <select id="categoria" name="categoria">
                        <option value="">Selecione uma categoria</option>
                        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <select id="tipo" name="tipo">
                        <option value="">Selecione um tipo</option>
                        <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <select id="fase" name="fase">
                        <option value="">Selecione uma fase</option>
                        <option value="filhote">Filhote</option>
                        <option value="adulto">Adulto</option>
                        <option value="castrado">Castrado</option>
                        <option value="todas">Todas</option>
                    </select>
                    <select id="marca" name="marca">
                        <option value="">Selecione uma marca</option>
                        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Filtrar</button>
                </form>
                </div>
                <br/>
            <h5>Exibindo <?php echo e($prods->count()); ?> de <?php echo e($prods->total()); ?> de Produtos (<?php echo e($prods->firstItem()); ?> a <?php echo e($prods->lastItem()); ?>)</h5>
            <table class="table table-striped table-ordered table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>Código</th>
                        <th>Foto</th>
                        <th>Nome</th>
                        <th>Tipo Animal</th>
                        <th>Tipo Fase</th>
                        <th>Marca</th>
                        <th>Embalagem</th>
                        <th>Preço</th>
                        <th>Estoque</th>
                        <th>Categoria</th>
                        <th>Ativo</th>
                        <th>Promoção</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($prod->id); ?></td>
                        <td width="120"><button type="button" data-toggle="modal" data-target="#exampleModalFoto<?php echo e($prod->id); ?>"><?php if($prod->foto!=""): ?><img style="margin:0px; padding:0px;" src="/storage/<?php echo e($prod->foto); ?>" alt="foto_produto" width="50%"><?php endif; ?></button></td>
                        <!-- Modal -->
                        <div class="modal fade bd-example-modal-lg" id="exampleModalFoto<?php echo e($prod->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <img src="/storage/<?php echo e($prod->foto); ?>" alt="foto_produto" style="width: 100%">
                            </div>
                            </div>
                        </div>
                        </div>
                        <td><?php echo e($prod->nome); ?></td>
                        <td><?php echo e($prod->tipo_animal->nome); ?></td>
                        <td><?php if($prod->tipo_fase=='filhote'): ?> Filhote <?php else: ?> <?php if($prod->tipo_fase=='adulto'): ?> Adulto <?php else: ?> <?php if($prod->tipo_fase=='castrado'): ?> Castrado <?php else: ?> Todas <?php endif; ?> <?php endif; ?> <?php endif; ?></td>
                        <td><?php echo e($prod->marca->nome); ?></td>
                        <td><?php echo e($prod->embalagem); ?></td>
                        <td><?php echo e('R$ '.number_format($prod->preco, 2, ',', '.')); ?></td>
                        <td><?php echo e($prod->estoque); ?></td>
                        <td><?php echo e($prod->categoria->nome); ?></td>
                        <td><?php if($prod->ativo=='1'): ?> Sim <?php else: ?> Não <?php endif; ?></td>
                        <td><?php if($prod->promocao=='1'): ?> Sim <?php else: ?> Não <?php endif; ?></td>
                        <td>
                            <button type="button" class="btn btn-sm btn-warning" data-toggle="modal" data-target="#exampleModal<?php echo e($prod->id); ?>" data-toggle="tooltip" data-placement="left" title="Editar">
                                <i class="material-icons md-48">edit</i>
                            </button>
                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal<?php echo e($prod->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Editar Produto</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="card border">
                                            <div class="card-body">
                                                <form action="/admin/produtos/editar/<?php echo e($prod->id); ?>" method="POST" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="form-group">
                                                        <label for="foto">Foto</label>
                                                        <input type="file" id="foto" name="foto" accept=".jpg,.png,jpeg">
                                                        <br/>
                                                        <b style="font-size: 80%;">Aceito apenas Imagens JPG e PNG (".jpg" e ".png")</b>
                                                        <label for="nome">Nome do Produto</label>
                                                        <input type="text" class="form-control" name="nome" id="nome" value="<?php echo e($prod->nome); ?>" required>
                                                        <br/>
                                                        <label for="tipo">Tipo de Animal</label>
                                                        <select id="tipo" name="tipo" required>
                                                            <option value="<?php echo e($prod->tipo_animal->id); ?>">Selecione o tipo do animal</option>
                                                            <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nome); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <br/><br/>
                                                        <label for="fase">Fase do Animal:</label>
                                                        <select id="fase" name="fase">
                                                            <option value="<?php echo e($prod->tipo_fase); ?>">Selecione a fase do animal</option>
                                                            <option value="filhote">Filhote</option>
                                                            <option value="adulto">Adulto</option>
                                                            <option value="castrado">Castrado</option>
                                                            <option value="todas">Todas</option>
                                                        </select>
                                                        <br/><br/>
                                                        <label for="marca">Marca</label>
                                                        <select id="marca" name="marca" required>
                                                            <option value="<?php echo e($prod->marca->id); ?>">Selecione a categoria do produto</option>
                                                            <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->nome); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <br/><br/>
                                                        <label for="embalagem">Embalagem do Produto</label>
                                                        <input type="text" class="form-control" name="embalagem" id="embalagem" value="<?php echo e($prod->embalagem); ?>" required>
                                                        <br/>
                                                        <label for="preco">Preço do Produto</label>
                                                        <input type="text" class="form-control" name="preco" id="preco" value="<?php echo e($prod->preco); ?>" required>
                                                        <br/>
                                                        <label for="estoque">Estoque do Produto</label>
                                                        <input type="number" class="form-control" name="estoque" id="estoque" value="<?php echo e($prod->estoque); ?>" required>
                                                        <br><br/>
                                                        <label for="categoria">Categoria</label>
                                                        <select id="categoria" name="categoria" required>
                                                            <option value="<?php echo e($prod->categoria->id); ?>">Selecione</option>
                                                            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->nome); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <h5>Ativo?</h5>
                                                        <input type="radio" id="sim" name="ativo" value="1" <?php if($prod->ativo=="1"): ?> checked <?php endif; ?> required>
                                                        <label for="sim">Sim</label>
                                                        <input type="radio" id="nao" name="ativo" value="0" <?php if($prod->ativo=="0"): ?> checked <?php endif; ?> required>
                                                        <label for="nao">Não</label>
                                                        <h5>Promoção?</h5>
                                                        <input type="radio" id="sim" name="promocao" value="1" <?php if($prod->promocao=="1"): ?> checked <?php endif; ?> required>
                                                        <label for="sim">Sim</label>
                                                        <input type="radio" id="nao" name="promocao" value="0" <?php if($prod->promocao=="0"): ?> checked <?php endif; ?> required>
                                                        <label for="nao">Não</label>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-primary btn-sn">Salvar</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <a href="/admin/produtos/apagar/<?php echo e($prod->id); ?>" class="btn btn-sm btn-danger" data-toggle="tooltip" data-placement="right" title="Excluir"><i class="material-icons md-48">delete</i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <div class="card-footer">
            <?php echo e($prods->links()); ?>

        </div>
    </div>
    <br>
    <a href="/admin/cadastros" class="btn btn-success"data-toggle="tooltip" data-placement="bottom" title="Voltar"><i class="material-icons white">reply</i></a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin', ["current"=>"cadastros"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxsa\Desktop\GitHub\laravel-ecommerce-pet67\resources\views/cadastros/produtos.blade.php ENDPATH**/ ?>