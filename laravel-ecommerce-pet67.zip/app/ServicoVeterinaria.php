<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServicoVeterinaria extends Model
{
    //
}
